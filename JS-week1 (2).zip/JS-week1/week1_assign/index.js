// This is my first JavaScript code!
console.log('Hello World');

